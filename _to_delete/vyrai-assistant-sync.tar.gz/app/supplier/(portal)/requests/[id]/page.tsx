import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { Card } from "@/components/ui/Card";
import { Badge, OfferStatusBadge } from "@/components/ui/Badge";
import { DeadlineCountdown } from "@/components/ui/Countdown";
import { BackLink } from "@/components/ui/BackLink";
import { SupplierOfferForm } from "@/components/app/SupplierOfferForm";
import { getCurrentUser } from "@/lib/auth";
import { getSupplierAccountByOwner, getSupplierEffectiveTierDefinition, getSupplierLead, getSupplierOfferForRequest } from "@/lib/data/store";
import { EVENT_TYPE_LABELS, SUPPLIER_CATEGORY_LABELS } from "@/lib/types";
import { formatCurrency } from "@/lib/config";
import { CheckCircle2, MapPin, MessageSquare, Users } from "lucide-react";

export const metadata = { title: "Aanvraag — Vyra voor leveranciers" };

export default async function SupplierRequestDetailPage(props: PageProps<"/supplier/requests/[id]">) {
  const { id } = await props.params;

  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const supplier = await getSupplierAccountByOwner(user.id);
  if (!supplier) redirect("/supplier/onboarding");

  const lead = await getSupplierLead(supplier.id, id);
  if (!lead) notFound();

  const [existingOffer, tierDefinition] = await Promise.all([
    getSupplierOfferForRequest(supplier.id, id),
    getSupplierEffectiveTierDefinition(supplier.id),
  ]);

  return (
    <div className="mx-auto max-w-2xl">
      <BackLink fallbackHref="/supplier/requests" label="Terug naar aanvragen" />

      <div className="mt-4 flex items-start justify-between gap-3">
        <div>
          <p className="flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-ink-faint">
            {SUPPLIER_CATEGORY_LABELS[lead.request.categoryKey]}
            {lead.request.isDirect && <Badge tone="clay">Maatwerkaanvraag</Badge>}
          </p>
          <h1 className="mt-1 font-display text-2xl text-ink">{lead.event.name}</h1>
          <p className="mt-1 text-sm text-ink-soft">{EVENT_TYPE_LABELS[lead.event.type]}</p>
        </div>
        {!existingOffer && <DeadlineCountdown deadlineIso={lead.request.deadlineAt} />}
      </div>

      <Link
        href={`/supplier/messages/${lead.request.id}`}
        className="chip-hover mt-4 inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-3.5 py-2 text-sm font-medium text-ink-soft hover:border-sage/50 hover:text-ink"
      >
        <MessageSquare className="size-4" /> Naar het gesprek
      </Link>

      <Card className="mt-6">
        <h2 className="mb-3 font-display text-lg text-ink">Details van het evenement</h2>
        <div className="grid grid-cols-1 gap-3 text-sm sm:grid-cols-2">
          <Detail label="Datum" value={lead.event.date ?? "Nog niet bepaald"} />
          <Detail
            label="Locatie"
            value={lead.event.locationLabel ?? "Niet opgegeven"}
            icon={<MapPin className="size-3.5" />}
          />
          <Detail
            label="Gasten"
            value={
              lead.event.guestCountAdults != null
                ? `${lead.event.guestCountAdults}${lead.event.guestCountChildren ? ` + ${lead.event.guestCountChildren} kinderen` : ""}`
                : "Niet opgegeven"
            }
            icon={<Users className="size-3.5" />}
          />
          {lead.request.budgetCents && <Detail label="Budget-indicatie" value={formatCurrency(lead.request.budgetCents)} />}
        </div>

        {lead.request.desiredService && (
          <div className="mt-4 border-t border-line-soft pt-4">
            <p className="text-xs font-medium uppercase tracking-wide text-ink-faint">Gevraagde dienst</p>
            <p className="mt-1 text-sm text-ink-soft">{lead.request.desiredService}</p>
          </div>
        )}
        {lead.request.specialRequests && (
          <div className="mt-3">
            <p className="text-xs font-medium uppercase tracking-wide text-ink-faint">Bijzondere wensen</p>
            <p className="mt-1 text-sm text-ink-soft">{lead.request.specialRequests}</p>
          </div>
        )}
      </Card>

      <div className="mt-6">
        {existingOffer ? (
          <Card className="flex items-center gap-3 border-success-50 bg-success-50">
            <CheckCircle2 className="size-5 text-success" />
            <div>
              <p className="font-medium text-ink">Je hebt al een offerte ingediend voor deze aanvraag</p>
              <p className="text-sm text-ink-soft">Verstuurd voor {formatCurrency(existingOffer.totalPriceCents)}. <OfferStatusBadge status={existingOffer.status} /></p>
            </div>
          </Card>
        ) : (
          <SupplierOfferForm
            requestId={lead.request.id}
            eventId={lead.event.id}
            categoryKey={lead.request.categoryKey}
            assistantEnabled={tierDefinition.assistantTier >= 1}
          />
        )}
      </div>
    </div>
  );
}

function Detail({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <div>
      <p className="text-xs font-medium uppercase tracking-wide text-ink-faint">{label}</p>
      <p className="mt-0.5 flex items-center gap-1.5 text-ink">{icon}{value}</p>
    </div>
  );
}
